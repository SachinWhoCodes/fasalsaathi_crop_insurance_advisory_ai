import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useTranslation } from 'react-i18next';
import { Calendar, Sprout, Loader2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { createReport } from '@/lib/api';

const formSchema = z.object({
  crop: z.string().min(1, 'Crop is required'),
  seed_type: z.string().min(1, 'Seed type is required'),
  soil: z.string().min(1, 'Soil type is required'),
  district: z.string().min(1, 'District is required'),
  season: z.string().min(1, 'Season is required'),
  state: z.string().min(1, 'State is required'),
  sowing_date: z.string().min(1, 'Sowing date is required'),
});

type FormValues = z.infer<typeof formSchema>;

const processingSteps = [
  { step: 1, message: 'Analyzing crop data...', duration: 2000 },
  { step: 2, message: 'Evaluating soil conditions...', duration: 2000 },
  { step: 3, message: 'Assessing climate risks...', duration: 2000 },
  { step: 4, message: 'Calculating risk scores...', duration: 2000 },
  { step: 5, message: 'Generating recommendations...', duration: 2000 },
  { step: 6, message: 'Finalizing report...', duration: 1000 },
];

export default function FormOnboard() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [progress, setProgress] = useState(0);

  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      crop: '',
      seed_type: '',
      soil: '',
      district: '',
      season: '',
      state: '',
      sowing_date: '',
    },
  });

  const onSubmit = async (data: FormValues) => {
    console.log('Form submitted:', data);
    setIsProcessing(true);
    setCurrentStep(0);
    setProgress(0);

    // Simulate processing with steps
    for (let i = 0; i < processingSteps.length; i++) {
      setCurrentStep(i);
      setProgress(((i + 1) / processingSteps.length) * 100);
      await new Promise(resolve => setTimeout(resolve, processingSteps[i].duration));
    }

    // Create report and navigate
    try {
      const result = await createReport('ready');
      navigate(`/reports/${result.reportId}`);
    } catch (error) {
      console.error('Error creating report:', error);
      setIsProcessing(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5 py-8 px-4">
      <div className="container mx-auto max-w-2xl">
        <Card className="border-primary/20 shadow-lg">
          <CardHeader className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-primary/10 p-2">
                <Sprout className="h-6 w-6 text-primary" />
              </div>
              <CardTitle className="text-2xl">Crop Onboarding</CardTitle>
            </div>
            <CardDescription>
              Fill in your crop details to get personalized risk assessment and insurance recommendations
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                <div className="grid gap-6 md:grid-cols-2">
                  <FormField
                    control={form.control}
                    name="crop"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Crop</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Wheat, Rice, Cotton" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="seed_type"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Seed Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select seed type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="hybrid">Hybrid</SelectItem>
                            <SelectItem value="traditional">Traditional</SelectItem>
                            <SelectItem value="organic">Organic</SelectItem>
                            <SelectItem value="gmo">GMO</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="soil"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Soil Type</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select soil type" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="clay">Clay</SelectItem>
                            <SelectItem value="loam">Loam</SelectItem>
                            <SelectItem value="sandy">Sandy</SelectItem>
                            <SelectItem value="silt">Silt</SelectItem>
                            <SelectItem value="peat">Peat</SelectItem>
                            <SelectItem value="chalky">Chalky</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="season"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Season</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Select season" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="kharif">Kharif (Monsoon)</SelectItem>
                            <SelectItem value="rabi">Rabi (Winter)</SelectItem>
                            <SelectItem value="zaid">Zaid (Summer)</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="state"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>State</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Punjab, Maharashtra" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="district"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>District</FormLabel>
                        <FormControl>
                          <Input placeholder="e.g., Ludhiana, Pune" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="sowing_date"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Sowing Date</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <Input type="date" {...field} />
                          <Calendar className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <Button type="submit" className="w-full" size="lg" disabled={isProcessing}>
                  {isProcessing ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Processing...
                    </>
                  ) : (
                    'Submit & Generate Report'
                  )}
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>

      {/* Processing Dialog */}
      <Dialog open={isProcessing} onOpenChange={() => {}}>
        <DialogContent className="sm:max-w-md" hideCloseButton>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              Processing Your Data
            </DialogTitle>
            <DialogDescription>
              Please wait while we analyze your crop information and generate insights
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 py-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between text-sm">
                <span className="text-muted-foreground">
                  {processingSteps[currentStep]?.message}
                </span>
                <span className="font-medium">{Math.round(progress)}%</span>
              </div>
              <Progress value={progress} className="h-2" />
            </div>

            <div className="space-y-2">
              {processingSteps.map((step, index) => (
                <div
                  key={index}
                  className={`flex items-center gap-2 text-sm transition-opacity ${
                    index <= currentStep ? 'opacity-100' : 'opacity-30'
                  }`}
                >
                  {index < currentStep ? (
                    <div className="h-4 w-4 rounded-full bg-primary flex items-center justify-center">
                      <svg className="h-3 w-3 text-primary-foreground" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                      </svg>
                    </div>
                  ) : index === currentStep ? (
                    <Loader2 className="h-4 w-4 animate-spin text-primary" />
                  ) : (
                    <div className="h-4 w-4 rounded-full border-2 border-muted" />
                  )}
                  <span className={index <= currentStep ? 'text-foreground' : 'text-muted-foreground'}>
                    {step.message}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
